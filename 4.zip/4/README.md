# hifive × DeviceConnectで体験するWoTハンズオンデモ


[hifive](http://www.htmlhifive.com)と[DeviceConnect](https://github.com/DeviceConnect)を組み合わせてWebブラウザからデバイスを操作するWoT（Web of Things）を体験するハンズオンのデモアプリです。

以下の機能があります。

- バイブレーション
- ライトのオン、オフ
- 通知

## LICENSE

MIT
