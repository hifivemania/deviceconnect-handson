$(function() {
  // DOM構築完了
  
  // ロジックを定義する
  var ajaxLogic = {
    __name: 'ajaxLogic',
    
    // 3. データを取得して返却
    getLocalData: function(path) {
    } 
  };
  
  // コントローラの定義
  var logicController = {
    __name: 'logicController',
    ajaxLogic: ajaxLogic,
    
    // 1. ボタンを押した時の処理
    '#button click': function() {
    },
    
    // 2. データを取得して表示するまでの処理
    getData: function(response) {
    }
  };

  // コントローラ化する
  h5.core.controller('body', logicController);
});
